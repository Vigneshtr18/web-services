
const questions = [
  {
    question: "What is a primary benefit of Web Services?",
    options: ["Increased hardware cost", "Vendor lock-in", "Platform independence", "Manual integration"],
    answer: 2
  },
  {
    question: "Which architecture type was used in early computing systems?",
    options: ["Client-server", "Service-oriented", "Mainframe", "Cloud"],
    answer: 2
  },
  {
    question: "In a client-server architecture, the client typically:",
    options: ["Processes backend logic", "Hosts the database", "Sends requests to the server", "Provides physical storage"],
    answer: 2
  },
  {
    question: "The Internet enabled which major shift in architecture?",
    options: ["Manual computing", "Centralized databases", "Distributed systems", "Dumb terminals"],
    answer: 2
  },
  {
    question: "Which of the following best describes thin clients?",
    options: ["Handles all processing locally", "Has powerful CPU and RAM", "Relies on server for processing", "Requires no network"],
    answer: 2
  },
  {
    question: "What is a web service?",
    options: ["A web browser", "A network cable", "Software that provides a service over the web", "An antivirus"],
    answer: 2
  },
  {
    question: "SOA stands for:",
    options: ["Software On Application", "Service-Oriented Architecture", "Secure Online Access", "Structured Object Application"],
    answer: 1
  },
  {
    question: "Which client type is most dependent on the server for processing?",
    options: ["Thick client", "Mobile client", "Dumb terminal", "Desktop client"],
    answer: 2
  },
  {
    question: "Which is an example of a mobile client?",
    options: ["ATM", "Android phone app", "Web browser on PC", "Printer"],
    answer: 1
  },
  {
    question: "Which XML element starts an XML document?",
    options: ["<doc>", "<html>", "<?xml version='1.0'?>", "<!--comment-->"],
    answer: 2
  },
  {
    question: "In SOA, services are:",
    options: ["Loosely coupled", "Tightly bound", "Hardware dependent", "GUI-based only"],
    answer: 0
  },
  {
    question: "What does XML stand for?",
    options: ["Extra Markup Language", "Extended Management Language", "Extensible Markup Language", "Executable Markup Logic"],
    answer: 2
  },
  {
    question: "Which of the following is a valid XML syntax rule?",
    options: ["Tags must be lowercase", "Tags must be closed", "No use of attributes", "Tags can be left open"],
    answer: 1
  },
  {
    question: "What is used to validate XML structure?",
    options: ["CSS", "HTTP", "DTD/Schema", "SQL"],
    answer: 2
  },
  {
    question: "Which is a stage in web service application setup?",
    options: ["Web crawling", "Stage Set", "Version compiling", "Static binding"],
    answer: 1
  },
  {
    question: "Which component enables communication in web services?",
    options: ["TCP/IP", "XML", "SOAP", "CSS"],
    answer: 2
  },
  {
    question: "A thick client typically:",
    options: ["Does no processing", "Does all server tasks", "Performs some processing locally", "Only handles UI"],
    answer: 2
  },
  {
    question: "Which markup language is designed to transport and store data?",
    options: ["HTML", "CSS", "XML", "PHP"],
    answer: 2
  },
  {
    question: "What ensures industry-wide acceptance of web services?",
    options: ["Proprietary formats", "Open standards like XML and SOAP", "Static hosting", "No documentation"],
    answer: 1
  },
  {
    question: "In distributed architecture, services are located:",
    options: ["On a single machine", "Centrally on mainframe", "Across multiple systems", "Only on local devices"],
    answer: 2
  }
];

const form = document.getElementById("quizForm");

questions.forEach((q, i) => {
  let div = document.createElement("div");
  div.innerHTML = "<p>" + (i + 1) + ". " + q.question + "</p>";
  q.options.forEach((opt, j) => {
    div.innerHTML += `<label><input type="radio" name="q${i}" value="${j}"> ${opt}</label><br>`;
  });
  form.appendChild(div);
});

document.getElementById("submitBtn").onclick = () => {
  let score = 0;
  questions.forEach((q, i) => {
    const selected = document.querySelector('input[name="q' + i + '"]:checked');
    if (selected && parseInt(selected.value) === q.answer) {
      score++;
    }
  });
  document.getElementById("result").textContent = "Your score: " + score + " / 20";
};
